; F9.ASM  first working code for fader using PIC16C71   11 March 1996
        LIST    F=INHX8M,R=DEC,P=16C71
        INCLUDE "\PIC\SRC\P16C71.INC"
        INCLUDE "\PIC\SRC\MACROS.ASM"

; ----------   MACROS   ----------

BANK0   MACRO
        BCF     STATUS,RP0
        ENDM

BANK1   MACRO
        BSF     STATUS,RP0
        ENDM

; ----------   .   ----------

; ----------   RAM   ----------

        ORG     $0C

W_ISR   RES     1
ST_ISR  RES     1
AD_ISR  RES     1
I_ISR   RES     1

SHOW    RES     1

FLAGS   RES     1
DISPLAY EQU     0

TXSR    RES     1
I       RES     1

; ----------   PORTB BITS   ----------

S1IN    EQU     0
S2IN    EQU     1
OKAY    EQU     2
TALLY   EQU     3
DAC     EQU     4
LEDS    EQU     5
SCLK    EQU     6
SDATA   EQU     7

; ----------   CODE   ----------

        ORG     0

RESET   XORLW   $FF
        XORLW   $FF
        XORLW   $FF
        GOTO    INIT

; ----------   INTERRUPT SUBROUTINE   ----------

        ORG     4

ISR     MOVWF   W_ISR
        SWAPF   STATUS,W
        MOVWF   ST_ISR

        IFCLR   INTCON,T0IF
        GOTO    EXITISR

        BANK0
        MOVLW   156
        MOVWF   TMR0
        BCF     INTCON,T0IF
        BCF     PORTB,TALLY

        BSF     ADCON0,GO        ; START A/D CONVERSION
ISR_L1  NOP
        IFSET   ADCON0,GO
        GOTO    ISR_L1

        BSF     PORTB,TALLY

        MOVF    ADRES,W
        SUBWF   AD_ISR,W
        IFZ
        GOTO    EXITISR

        BCF     PORTB,DAC       ; UPDATE DAC OUTPUT
        BSF     FLAGS,DISPLAY

        MOVLW   HIGH MSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        MOVWF   AD_ISR
        CALL    MSBTAB
        MOVWF   TXSR

        MOVLW   4
        MOVWF   I_ISR
ISR_L2  BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        BSF     PORTB,SCLK
        DECFSZ  I_ISR,F
        GOTO    ISR_L2

        MOVLW   HIGH LSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        CALL    LSBTAB
        MOVWF   TXSR
        MOVWF   SHOW

        MOVLW   8
        MOVWF   I_ISR
ISR_L3  BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        BSF     PORTB,SCLK
        DECFSZ  I_ISR,F
        GOTO    ISR_L3

        BSF     PORTB,DAC

EXITISR SWAPF   ST_ISR,W
        MOVWF   STATUS
        SWAPF   W_ISR,F
        SWAPF   W_ISR,W
        RETFIE

; ----------   LSBTAB   ----------

        ORG     $FE
LSBTAB  INCF    PCLATH,F
        ADDWF   PCL,F
               
        INCLUDE "LSB."

; ----------   INITIALIZATION CODE   ----------

INIT    XORLW   $FF             ; UNPROGRAMED NOP

        MOVLW   $0F             ; INITIALIZE PORTA & PORTB
        MOVWF   PORTA
        MOVLW   $FF
        MOVWF   PORTB

        BANK1
        MOVLW   $0F             ; SET DATA DIRECTION OF PORTA & PORTB
        MOVWF   TRISA
        MOVLW   $00
        MOVWF   TRISB
        MOVLW   $81
        MOVWF   OPTION_REG
        MOVLW   $02
        MOVWF   ADCON1
        BANK0

        MOVLW   $C1
        MOVWF   ADCON0

        CLRF    AD_ISR
        CLRF    FLAGS
        BCF     PORTB,OKAY

        CLRF    INTCON
        BSF     INTCON,T0IE
        BSF     INTCON,GIE

; ----------   MAIN CODE   ----------

MAIN
        IFCLR   FLAGS,DISPLAY
        GOTO    MAIN
        BCF     FLAGS,DISPLAY

        COMF    AD_ISR,W
        MOVWF   TXSR
        BCF     PORTB,LEDS

        MOVLW   8
        MOVWF   I
MAIN_L2 BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        BSF     PORTB,SCLK
        DECFSZ  I,F
        GOTO    MAIN_L2

        COMF    SHOW,W
        MOVWF   TXSR

        MOVLW   8
        MOVWF   I
MAIN_L3 BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        BSF     PORTB,SCLK
        DECFSZ  I,F
        GOTO    MAIN_L3

        BSF     PORTB,LEDS
        GOTO    MAIN


; ----------   MSBTAB   ----------

        ORG     $2FE
MSBTAB  INCF    PCLATH,F
        ADDWF   PCL,F

        INCLUDE "MSB."

        END
