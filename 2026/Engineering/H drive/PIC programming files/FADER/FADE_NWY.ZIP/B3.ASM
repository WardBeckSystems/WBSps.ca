
        LIST    F=INHX8M,R=DEC,P=16C73
        INCLUDE "\PIC\SRC\P16C73.INC"
        INCLUDE "\PIC\SRC\MACROS.ASM"

; ----------   RAM   ----------


        ORG     $20
W_ISR   RES     1               ; MIRRORED AT $A0
ST_ISR  RES     1
PCH_ISR RES     1
AD_ISR  RES     1
TX_ISR  RES     1

OUT1    RES     1
OUT2    RES     1
I       RES     1
TEMP1   RES     1
TEMP2   RES     1
STATE   RES     1
FLAGS   RES     1

        ORG     $30
KTAB    RES     16
CHONKS  RES     1

        ORG     $A0
W_ISRM  RES     1               ; MIRRORED AT $20


; ----------   PORTA BITS   ----------

MASTAD  EQU     0               ; analog input
SLAVAD  EQU     1               ; anolog input
CHONSW  EQU     2               ; in
XXX     EQU     3               ; unused anolog input
GMCNCL  EQU     4               ; bi
CHONC   EQU     5               ; out
TALLY   EQU     5

; ----------   PORTB BITS   ----------

PFAIL   EQU     0               ; in
GCS     EQU     1               ; out
ACS     EQU     2               ; out
BCS     EQU     3               ; out
ROW1    EQU     4               ; in
ROW2    EQU     5               ; in
ROW3    EQU     6               ; in
ROW4    EQU     7               ; in

; ----------   PORTC BITS   ----------

OKAY    EQU     0               ; out
EECS    EQU     1               ; out
EXTCHON EQU     2               ; in
MSCK    EQU     3               ; in
MSDO    EQU     4               ; in
MSDI    EQU     5               ; out
SCLK    EQU     6               ; out
SDATA   EQU     7               ; out

; ----------   EQUATES   ----------

DELAY   EQU     6               ; 500 us WITH OPTION ??
NKEYS   EQU     16              ; NUMBER OF KEYS

COL1    EQU     00000010B       ; PORTB CODES FOR KEYBOARD COLUMS
COL2    EQU     00000110B
COL3    EQU     00001010B
COL4    EQU     00001110B

CHIP1   EQU     00000110B       ; PORTB CODES FOR CHIP SELECTS
CHIP2   EQU     00001010B
CHIP3   EQU     00001110B


; ----------   MACROS   ----------

BANK0   MACRO
        BCF     STATUS,RP0
        ENDM

BANK1   MACRO
        BSF     STATUS,RP0
        ENDM

TXBIT   MACRO   F,BIT
        IFSET   F,BIT
        BSF     PORTC,SDATA
        IFCLR   F,BIT
        BCF     PORTC,SDATA
        BCF     PORTC,SCLK
        BSF     PORTC,SCLK
        ENDM

CHECK   MACRO   X
        IFSET   KTAB+X,0
        INCF    TEMP1,F
        ENDM

; ----------   .   ----------

; ----------   CODE   ----------

        ORG     0

RESET   XORLW   $FF
        XORLW   $FF
        XORLW   $FF
        GOTO    INIT

; ----------   INTERRUPT SUBROUTINE   ----------

        ORG     4

ISR     MOVWF   W_ISR
        SWAPF   STATUS,W
        BANK0
        MOVWF   ST_ISR
        MOVF    PCLATH,W
        MOVWF   PCH_ISR
        MOVLW   HIGH ISR
        MOVWF

        IFCLR   INTCON,T0IF
        GOTO    EXITISR

        MOVLW   DELAY
        MOVWF   TMR0
        BCF     INTCON,T0IF
        BCF     PORTA,TALLY

        BSF     ADCON0,GO        ; START A/D CONVERSION
ISR_L1  NOP
        IFSET   ADCON0,GO
        GOTO    ISR_L1

        BSF     PORTA,TALLY

        MOVLW   HIGH ISR
        MOVWF   PCLATH
        INCF    STATE,F
        MOVF    STATE,W
        ANDLW   $07
        ADDWF   PCL,F
        GOTO    STATE0
        GOTO    STATE1
        GOTO    STATE2
        GOTO    STATE3
        GOTO    STATE4
        GOTO    STATE5
        GOTO    STATE6
        GOTO    STATE7

; ----------   NEXT STATE TABLE1   ----------

; DEBOUNCE INPUT STATE MACHINE
; BIT 0 INPUT - ACTIVE HIGH
; BIT 1 STATE
; BIT 2 STATE
; BIT 3 OUTPUT - SET AFTER INPUT=1 FOUR CONSECUTIVE TIMES
; BIT 4 OUTPUT - SET AFTER BIT 3 TOGGLES
; BIT 5 OUTPUT - SET WHEN BOTH BITS 3 & 4 ARE SET

KEYBIT  EQU     3
KCH     EQU     4
PRESS   EQU     7

NEXT1   ANDLW   $0F     ; DEBOUNCE INPUT STATE MACHINE
        ADDWF   PCL,F

        RETLW   0       ; KEYBIT CLEAR WHILE INPUT=0
        RETLW   2
        RETLW   0
        RETLW   4
        RETLW   0
        RETLW   6
        RETLW   0
        RETLW   8+16+128;4TH INPUT=1 SO SET KEYBIT

        RETLW   10
        RETLW   8       ; KEYBIT SET WHILE INPUT=1
        RETLW   12
        RETLW   8
        RETLW   14
        RETLW   8
        RETLW   0+16    ; 4TH INPUT=0 SO CLEAR KEYBIT
        RETLW   8

; ----------   STATES 0 TO 7   ----------

STATE0
        MOVLW   HIGH SENDDAC
        MOVWF   PCLATH
        CALL    SENDDAC
        GOTO    EXITISR
STATE1
        MOVLW   HIGH SENDDAC
        MOVWF   PCLATH
        CALL    SENDDAC
        MOVLW   ROW1
        MOVWF   PORTB
        GOTO    EXITISR
STATE2
        IFCLR   PORTB,4
        INCF    15+KTAB,F
        IFCLR   PORTB,5
        INCF    14+KTAB,F
        IFCLR   PORTB,6
        INCF    13+KTAB,F
        IFCLR   PORTB,7
        INCF    12+KTAB,F
        MOVLW   HIGH SENDDAC
        MOVWF   PCLATH
        CALL    SENDDAC
        MOVLW   ROW2
        MOVWF   PORTB
        GOTO    EXITISR
STATE3
        IFCLR   PORTB,4
        INCF    11+KTAB,F
        IFCLR   PORTB,5
        INCF    10+KTAB,F
        IFCLR   PORTB,6
        INCF    9+KTAB,F
        IFCLR   PORTB,7
        INCF    8+KTAB,F
        MOVLW   HIGH SENDDAC
        MOVWF   PCLATH
        CALL    SENDDAC
        MOVLW   ROW3
        MOVWF   PORTB
        GOTO    EXITISR
STATE4
        IFCLR   PORTB,4
        INCF    7+KTAB,F
        IFCLR   PORTB,5
        INCF    6+KTAB,F
        IFCLR   PORTB,6
        INCF    5+KTAB,F
        IFCLR   PORTB,7
        INCF    4+KTAB,F
        MOVLW   HIGH SENDDAC
        MOVWF   PCLATH
        CALL    SENDDAC
        MOVLW   ROW4
        MOVWF   PORTB
        GOTO    EXITISR
STATE5
        IFCLR   PORTB,4
        INCF    3+KTAB,F
        IFCLR   PORTB,5
        INCF    2+KTAB,F
        IFCLR   PORTB,6
        INCF    1+KTAB,F
        IFCLR   PORTB,7
        INCF    0+KTAB,F
        MOVLW   HIGH SENDDAC
        MOVWF   PCLATH
        CALL    SENDDAC
        MOVLW   CHIP1
        MOVWF   PORTB
        GOTO    EXITISR
STATE6
        MOVLW   HIGH SENDDAC
        MOVWF   PCLATH
        CALL    SENDDAC

        IFCLR   PORTA,CHONSW    ; CHECK CHON SWITCH
        INCF    CHONKS,F
        MOVF    CHONKS,W
        CALL    NEXT1
        MOVWF   CHONKS

        CLRF    TEMP1
        CHECK   0
        CHECK   1
        CHECK   2
        CHECK   3
        CHECK   4
        CHECK   5
        CHECK   6
        CHECK   7
        CHECK   8
        CHECK   9
        CHECK   10
        CHECK   11
        CHECK   12
        CHECK   13
        CHECK   14
        CHECK   15

        MOVLW   3
        SUBWF   TEMP1,W
        IFCC
        GOTO    EXITISR         ; VALID
        CALL    CLEAR
        INCF    STATE,F
        GOTO    EXITISR

STATE7
        MOVLW   HIGH SENDDAC
        MOVWF   PCLATH
        CALL    SENDDAC
VALID
        MOVLW   KTAB
        MOVWF   FSR
UPDATE
        MOVF    INDF,W
        CALL    NEXT1
        MOVWF   INDF
        RLF     INDF,W
        RLF     TEMP1,F
        RLF     TEMP2,F
        INCF    FSR,F
        IFSET   FSR,4
        GOTO    UPDATE

        MOVF    TEMP1,W
        XORWF   OUT1,F
        MOVF    TEMP2,W
        XORWF   OUT2,F

EXITISR SWAPF   ST_ISR,W
        MOVWF   STATUS
        SWAPF   W_ISR,F
        SWAPF   W_ISR,W
        RETFIE

; ----------   LSBTAB   ----------

        ORG     $FE
LSBTAB  INCF    PCLATH,F
        ADDWF   PCL,F
               
        INCLUDE "LSB."


; ----------   SEND TO DAC   ----------

SENDDAC
        MOVF    ADRES,W
        SUBWF   AD_ISR,W
        IFZ
        RETURN                  ; DO NOTHING IF NO CHANGE

        MOVLW   CHIP1
        MOVWF   PORTB
        BCF     PORTB,GCS       ; UPDATE DAC OUTPUT

        MOVLW   HIGH MSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        MOVWF   AD_ISR
        CALL    MSBTAB
        MOVWF   TX_ISR

        TXBIT   TX_ISR,7
        TXBIT   TX_ISR,6
        TXBIT   TX_ISR,5
        TXBIT   TX_ISR,4

        MOVLW   HIGH LSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        CALL    LSBTAB
        MOVWF   TX_ISR

        TXBIT   TX_ISR,7
        TXBIT   TX_ISR,6
        TXBIT   TX_ISR,5
        TXBIT   TX_ISR,4
        TXBIT   TX_ISR,3
        TXBIT   TX_ISR,2
        TXBIT   TX_ISR,1
        TXBIT   TX_ISR,0

        BSF     PORTB,GCS
        RETURN

; ----------   INITIALIZATION CODE   ----------

INIT    XORLW   $FF             ; UNPROGRAMED NOP

        MOVLW   $0F             ; INITIALIZE PORTA & PORTB
        MOVWF   PORTA
        MOVLW   $FF
        MOVWF   PORTB

        BANK1
        MOVLW   $0F             ; SET DATA DIRECTION OF PORTA & PORTB
        MOVWF   TRISA
        MOVLW   $00
        MOVWF   TRISB
        MOVLW   $81
        MOVWF   OPTION_REG
        MOVLW   $02
        MOVWF   ADCON1
        BANK0

        MOVLW   $C1
        MOVWF   ADCON0

        CLRF    AD_ISR
        CLRF    FLAGS
        BCF     PORTB,OKAY

        CLRF    OUT1
        CLRF    OUT2

        CLRF    INTCON
        BSF     INTCON,T0IE
        BSF     INTCON,GIE

; ----------   MAIN CODE   ----------

MAIN

        COMF    AD_ISR,W
        MOVWF   TXSR
        BCF     PORTB,LEDS

        MOVLW   8
        MOVWF   I
MAIN_L2 BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        BSF     PORTB,SCLK
        DECFSZ  I,F
        GOTO    MAIN_L2

        COMF    SHOW,W
        MOVWF   TXSR

        MOVLW   8
        MOVWF   I
MAIN_L3 BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        BSF     PORTB,SCLK
        DECFSZ  I,F
        GOTO    MAIN_L3

        BSF     PORTB,LEDS
        GOTO    MAIN


; ----------   MSBTAB   ----------

        ORG     $2FE
MSBTAB  INCF    PCLATH,F
        ADDWF   PCL,F

        INCLUDE "MSB."



; ----------   CLEAR STATES   ----------

CLEAR   MOVLW   KTAB
        MOVWF   FSR
        MOVLW   8
CLEAR_L1
        ANDWF   INDF,F
        INCF    FSR,F
        IFSET   FSR,4
        GOTO    CLEAR_L1
        RETLW   0

; ----------   SEND TO 74HC595   ----------

SEND595
        MOVLW   CHIP2
        MOVWF   PORTB
        BCF     PORTB,GCS       ; UPDATE DAC OUTPUT

        TXBIT   OUT1,7
        TXBIT   OUT1,6
        TXBIT   OUT1,5
        TXBIT   OUT1,4
        TXBIT   OUT1,3
        TXBIT   OUT1,2
        TXBIT   OUT1,1
        TXBIT   OUT1,0

        TXBIT   OUT2,7
        TXBIT   OUT2,6
        TXBIT   OUT2,5
        TXBIT   OUT2,4
        TXBIT   OUT2,3
        TXBIT   OUT2,2
        TXBIT   OUT2,1
        TXBIT   OUT2,0

        BSF     PORTB,GCS
        RETURN

        END
