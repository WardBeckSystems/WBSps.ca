
        LIST    F=INHX8M,R=DEC,P=16C73
        INCLUDE "\PIC\SRC\P16C73.INC"
        INCLUDE "\PIC\SRC\MACROS.ASM"

; ----------   RAM   ----------


        ORG     $20
W_ISR   RES     1               ; MIRRORED AT $A0
ST_ISR  RES     1
PCH_ISR RES     1
AD_ISR  RES     1
TEMP1   RES     1
TEMP2   RES     1

OUT1    RES     1
OUT2    RES     1
STATE   RES     1
FLAGS   RES     1
I       RES     1

        ORG     $30
KTAB    RES     16
CHONKS  RES     1

        ORG     $A0
W_ISRM  RES     1               ; MIRRORED AT $20


; ----------   PORTA BITS   ----------

MASTAD  EQU     0               ; analog input
SLAVAD  EQU     1               ; anolog input
CHONSW  EQU     2               ; in
XXX     EQU     3               ; unused anolog input
GMCNCL  EQU     4               ; bi
CHONC   EQU     5               ; out

; ----------   PORTB BITS   ----------

PFAIL   EQU     0               ; in
GCS     EQU     1               ; out
ACS     EQU     2               ; out
BCS     EQU     3               ; out
ROW1    EQU     4               ; in
ROW2    EQU     5               ; in
ROW3    EQU     6               ; in
ROW4    EQU     7               ; in

; ----------   PORTC BITS   ----------
TALLY   EQU     1

OKAY    EQU     0               ; out
EECS    EQU     1               ; out
EXTCHON EQU     2               ; in
MSCK    EQU     3               ; in
MSDO    EQU     4               ; in
MSDI    EQU     5               ; out
SCLK    EQU     6               ; out
SDATA   EQU     7               ; out

; ----------   FLAG BITS   ----------

OUT     EQU     0

; ----------   EQUATES   ----------

DELAY   EQU     6               ; 500 us WITH OPTION $C0
NKEYS   EQU     16              ; NUMBER OF KEYS

COL1    EQU     00000010B       ; PORTB CODES FOR KEYBOARD COLUMS
COL2    EQU     00000110B
COL3    EQU     00001010B
COL4    EQU     00001110B

CHIP1   EQU     00000110B       ; PORTB CODES FOR CHIP SELECTS
CHIP2   EQU     00001010B
CHIP3   EQU     00001110B


; ----------   MACROS   ----------

BANK0   MACRO
        BCF     STATUS,RP0
        ENDM

BANK1   MACRO
        BSF     STATUS,RP0
        ENDM

TXBIT   MACRO   F,BIT
        IFSET   F,BIT
        BSF     PORTC,SDATA
        IFCLR   F,BIT
        BCF     PORTC,SDATA
        BCF     PORTC,SCLK
        BSF     PORTC,SCLK
        ENDM

CHECK   MACRO   X
        IFSET   KTAB+X,0
        INCF    TEMP1,F
        ENDM

; ----------   .   ----------

; ----------   CODE   ----------

        ORG     0

RESET   XORLW   $FF
        XORLW   $FF
        XORLW   $FF
        GOTO    INIT

; ----------   INTERRUPT SUBROUTINE   ----------

        ORG     4

ISR     MOVWF   W_ISR           ; SAVE W & STATUS
        SWAPF   STATUS,W
        BANK0
        MOVWF   ST_ISR

        MOVF    PCLATH,W        ; SAVE BACKGROUD PAGE
        MOVWF   PCH_ISR

        IFCLR   INTCON,T0IF
        GOTO    EXITISR

        MOVLW   HIGH ISR        ; SET PAGE FOR ISR
        MOVWF   PCLATH

        MOVLW   DELAY           ; RESET TIMER
        MOVWF   TMR0
        BCF     INTCON,T0IF
        BCF     PORTC,TALLY

        BSF     ADCON0,GO       ; START A/D CONVERSION
ISR_L1  NOP
        IFSET   ADCON0,GO
        GOTO    ISR_L1

        BSF     PORTC,TALLY

        MOVF    STATE,W         ; GOTO NEXT STATE
        INCF    STATE,F
        ANDLW   $07
        ADDWF   PCL,F
        GOTO    STATE0
        GOTO    STATE1
        GOTO    STATE2
        GOTO    STATE3
        GOTO    STATE4
        GOTO    STATE5
        GOTO    STATE6
        GOTO    STATE7

; ----------   NEXT STATE TABLE1   ----------

; DEBOUNCE INPUT STATE MACHINE
; BIT 0 INPUT - ACTIVE HIGH
; BIT 1 STATE
; BIT 2 STATE
; BIT 3 OUTPUT - SET AFTER INPUT=1 FOUR CONSECUTIVE TIMES
; BIT 4 OUTPUT - SET AFTER BIT 3 TOGGLES
; BIT 5 OUTPUT - SET WHEN BOTH BITS 3 & 4 ARE SET

KEYBIT  EQU     3
KCH     EQU     4
PRESS   EQU     7

NEXT1   ANDLW   $0F     ; DEBOUNCE INPUT STATE MACHINE
        ADDWF   PCL,F

        RETLW   0       ; KEYBIT CLEAR WHILE INPUT=0
        RETLW   2
        RETLW   0
        RETLW   4
        RETLW   0
        RETLW   6
        RETLW   0
        RETLW   8+16+128;4TH INPUT=1 SO SET KEYBIT

        RETLW   10
        RETLW   8       ; KEYBIT SET WHILE INPUT=1
        RETLW   12
        RETLW   8
        RETLW   14
        RETLW   8
        RETLW   0+16    ; 4TH INPUT=0 SO CLEAR KEYBIT
        RETLW   8

; ----------   CLEAR DEBOUNCE STATES   ----------

CLEAR   MOVLW   KTAB
        MOVWF   FSR
        MOVLW   $08
CLEAR_L1
        ANDWF   INDF,F
        INCF    FSR,F
        IFSET   FSR,4
        GOTO    CLEAR_L1
        RETURN

; ----------   STATES 0 TO 7   ----------

STATE0
        CALL    SENDDAC
        IFCLR   FLAGS,OUT
        GOTO    EXITISR
        BCF     FLAGS,OUT
        MOVLW   CHIP2           ; SEND TO 74HC595 CHIPS
        MOVWF   PORTB
        BCF     PORTB,GCS

        TXBIT   OUT1,7
        TXBIT   OUT1,6
        TXBIT   OUT1,5
        TXBIT   OUT1,4
        TXBIT   OUT1,3
        TXBIT   OUT1,2
        TXBIT   OUT1,1
        TXBIT   OUT1,0

        TXBIT   OUT2,7
        TXBIT   OUT2,6
        TXBIT   OUT2,5
        TXBIT   OUT2,4
        TXBIT   OUT2,3
        TXBIT   OUT2,2
        TXBIT   OUT2,1
        TXBIT   OUT2,0

        BSF     PORTB,GCS
        GOTO    EXITISR
STATE1
        CALL    SENDDAC
        MOVLW   ROW1            ; SET ROW1 LOW
        MOVWF   PORTB
        GOTO    EXITISR
STATE2
        IFCLR   PORTB,4         ; CHECK ROW1
        INCF    15+KTAB,F
        IFCLR   PORTB,5
        INCF    14+KTAB,F
        IFCLR   PORTB,6
        INCF    13+KTAB,F
        IFCLR   PORTB,7
        INCF    12+KTAB,F
        CALL    SENDDAC
        MOVLW   ROW2            ; SET ROW2 LOW
        MOVWF   PORTB
        GOTO    EXITISR
STATE3
        IFCLR   PORTB,4         ; CHECK ROW2
        INCF    11+KTAB,F
        IFCLR   PORTB,5
        INCF    10+KTAB,F
        IFCLR   PORTB,6
        INCF    9+KTAB,F
        IFCLR   PORTB,7
        INCF    8+KTAB,F
        CALL    SENDDAC
        MOVLW   ROW3            ; SET ROW3 LOW
        MOVWF   PORTB
        GOTO    EXITISR
STATE4
        IFCLR   PORTB,4         ; CHECK ROW3
        INCF    7+KTAB,F
        IFCLR   PORTB,5
        INCF    6+KTAB,F
        IFCLR   PORTB,6
        INCF    5+KTAB,F
        IFCLR   PORTB,7
        INCF    4+KTAB,F
        CALL    SENDDAC
        MOVLW   ROW4            ; SET ROW4 LOW
        MOVWF   PORTB
        GOTO    EXITISR
STATE5
        IFCLR   PORTB,4         ; CHECK ROW4
        INCF    3+KTAB,F
        IFCLR   PORTB,5
        INCF    2+KTAB,F
        IFCLR   PORTB,6
        INCF    1+KTAB,F
        IFCLR   PORTB,7
        INCF    0+KTAB,F
        CALL    SENDDAC
        GOTO    EXITISR
STATE6
        CALL    SENDDAC

        IFCLR   PORTA,CHONSW    ; CHECK CHON SWITCH
        INCF    CHONKS,F
        MOVF    CHONKS,W
        CALL    NEXT1
        MOVWF   CHONKS
        IFCLR   CHONKS,PRESS
        GOTO    DONT

        IFCLR   PORTA,CHONC
        GOTO    DONT1
        BCF     PORTA,CHONC
        GOTO    DONT
DONT1   BSF     PORTA,CHONC
DONT
        CLRF    TEMP1           ; COUNT NUMBER OF KEYS PRESSED
        CHECK   0
        CHECK   1
        CHECK   2
        CHECK   3
        CHECK   4
        CHECK   5
        CHECK   6
        CHECK   7
        CHECK   8
        CHECK   9
        CHECK   10
        CHECK   11
        CHECK   12
        CHECK   13
        CHECK   14
        CHECK   15

        MOVLW   3               ; TEST FOR MORE THAN TWO PRESSED
        SUBWF   TEMP1,W
        IFCC
        GOTO    EXITISR         ; IF MORE THAN 2 PRESSED THEN
        CALL    CLEAR           ; CLEAR STATES
        CLRF    STATE           ; DO NOT CHECK KEYS
        GOTO    EXITISR

STATE7
        CALL    SENDDAC
        MOVLW   KTAB            ; DEBOUNCE KEYS
        MOVWF   FSR
UPDATE
        MOVF    INDF,W
        CALL    NEXT1
        MOVWF   INDF
        RLF     INDF,W
        RLF     TEMP1,F         ; KEEP TRACK OF THOSE THAT CHANGE
        RLF     TEMP2,F
        INCF    FSR,F
        IFSET   FSR,4
        GOTO    UPDATE

        MOVF    TEMP1,W         ; TOGLE OUTPUTS
        IFNZ
        BSF     FLAGS,OUT
        XORWF   OUT1,F
        MOVF    TEMP2,W
        IFNZ
        BSF     FLAGS,OUT
        XORWF   OUT2,F

EXITISR
        MOVF    PCH_ISR,W       ; RESTORE PCLATH
        MOVWF   PCLATH
        SWAPF   ST_ISR,W
        MOVWF   STATUS          ; RESTORE STATUS
        SWAPF   W_ISR,F
        SWAPF   W_ISR,W         ; RESTORE W
        RETFIE

; ----------   SEND TO DAC   ----------

SENDDAC
        MOVF    ADRES,W
        SUBWF   AD_ISR,W
        IFZ
        RETURN                  ; DO NOTHING IF NO CHANGE

        MOVLW   CHIP1
        MOVWF   PORTB
        BCF     PORTB,GCS       ; UPDATE DAC OUTPUT

        MOVLW   HIGH MSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        MOVWF   AD_ISR
        CALL    MSBTAB
        MOVWF   TEMP1

        TXBIT   TEMP1,7
        TXBIT   TEMP1,6
        TXBIT   TEMP1,5
        TXBIT   TEMP1,4

        MOVLW   HIGH LSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        CALL    LSBTAB
        MOVWF   TEMP1

        TXBIT   TEMP1,7
        TXBIT   TEMP1,6
        TXBIT   TEMP1,5
        TXBIT   TEMP1,4
        TXBIT   TEMP1,3
        TXBIT   TEMP1,2
        TXBIT   TEMP1,1
        TXBIT   TEMP1,0

        BSF     PORTB,GCS
        RETURN

; ----------   INITIALIZATION CODE   ----------

INIT    XORLW   $FF             ; UNPROGRAMED NOP

        BANK0
        MOVLW   $3F             ; INITIALIZE PORTA & PORTB
        MOVWF   PORTA
        MOVLW   $FF
        MOVWF   PORTB
        MOVWF   PORTC

        BANK1
        MOVLW   $0F             ; SET DATA DIRECTION OF PORTA & PORTB
        MOVWF   TRISA
        MOVLW   $F1
        MOVWF   TRISB
        MOVLW   $1C
        MOVWF   TRISC
        MOVLW   $C0             ; TMR0 PRESCALER = 1MHz / 2
        MOVWF   OPTION_REG
        MOVLW   $04
        MOVWF   ADCON1
        BANK0

        BCF     PORTB,OKAY

        MOVLW   $C1
        MOVWF   ADCON0
        CLRF    AD_ISR

        CLRF    OUT1
        CLRF    OUT2
        CLRF    STATE
        CLRF    FLAGS
        CLRF    CHONKS

        CLRF    INTCON
        BSF     INTCON,T0IE
        BSF     INTCON,GIE

; ----------   MAIN CODE   ----------

MAIN

        GOTO    MAIN

; ----------   LSBTAB   ----------

        ORG     $CFE
LSBTAB  INCF    PCLATH,F
        ADDWF   PCL,F
               
        INCLUDE "LSB."


; ----------   MSBTAB   ----------

        ORG     $EFE
MSBTAB  INCF    PCLATH,F
        ADDWF   PCL,F

        INCLUDE "MSB."


        END
