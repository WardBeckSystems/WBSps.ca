        LIST    F=INHX8M,R=DEC,P=16C71
        INCLUDE "\PIC\SRC\P16C71.INC"
        INCLUDE "\PIC\SRC\MACROS.ASM"

; ----------   MACROS   ----------

BANK0   MACRO
        BCF     STATUS,RP0
        ENDM

BANK1   MACRO
        BSF     STATUS,RP0
        ENDM

; ----------   .   ----------

; ----------   RAM   ----------

        ORG     $0C

W_ISR   RES     1
ST_ISR  RES     1
AD_ISR  RES     1
TX_ISR  RES     1
I_ISR   RES     1

SHOW    RES     1

TXSR    RES     1

; ----------   PORTB BITS   ----------

S1IN    EQU     0
S2IN    EQU     1
OKAY    EQU     2
TALLY   EQU     3
DAC     EQU     4
LEDS    EQU     5
SCLK    EQU     6
SDATA   EQU     7

; ----------   CODE   ----------

        ORG     0

RESET   XORLW   $FF
        XORLW   $FF
        XORLW   $FF
        GOTO    INIT

; ----------   INTERRUPT SUBROUTINE   ----------

        ORG     4

ISR     MOVWF   W_ISR
        SWAPF   STATUS,W
        MOVWF   ST_ISR

        IFCLR   INTCON,T0IF
        GOTO    EXITISR

        BANK0
        MOVLW   156
        MOVWF   TMR0
        BCF     INTCON,T0IF
        BCF     PORTB,TALLY

        BSF     ADCON0,GO        ; START A/D CONVERSION
ISR_L1  NOP
        IFSET   ADCON0,GO
        GOTO    ISR_L1

        BSF     PORTB,TALLY

        MOVF    ADRES,W
        SUBWF   AD_ISR,W
        IFZ
        GOTO    EXITISR

        BCF     PORTB,DAC       ; UPDATE DAC OUTPUT

        MOVLW   HIGH MSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        MOVWF   AD_ISR
        CALL    MSBTAB
        MOVWF   TX_ISR

        MOVLW   4
        MOVWF   I_ISR
ISR_L2  BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TX_ISR,F
        BSF     PORTB,SCLK
        DECFSZ  I_ISR,F
        GOTO    ISR_L2

        MOVLW   HIGH LSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        CALL    LSBTAB
        MOVWF   TX_ISR
        MOVWF   SHOW

        MOVLW   8
        MOVWF   I_ISR
ISR_L3  BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TX_ISR,F
        BSF     PORTB,SCLK
        DECFSZ  I_ISR,F
        GOTO    ISR_L3

        BSF     PORTB,DAC

EXITISR SWAPF   ST_ISR,W
        MOVWF   STATUS
        SWAPF   W_ISR,F
        SWAPF   W_ISR,W
        RETFIE

; ----------   LSBTAB   ----------

        ORG     $FE
LSBTAB  INCF    PCLATH,F
        ADDWF   PCL,F
               
        RETLW   $B4     ; 1460
        RETLW   $F4     ; 1524
        RETLW   $33     ; 1587
        RETLW   $73     ; 1651
        RETLW   $B2     ; 1714
        RETLW   $F2     ; 1778
        RETLW   $32     ; 1842
        RETLW   $71     ; 1905

        RETLW   $B1     ; 1969
        RETLW   $F0     ; 2032
        RETLW   $30     ; 2096
        RETLW   $5C     ; 2140
        RETLW   $6C     ; 2156
        RETLW   $7D     ; 2173
        RETLW   $8E     ; 2190
        RETLW   $9F     ; 2207

        RETLW   $AF     ; 2223
        RETLW   $C0     ; 2240
        RETLW   $D1     ; 2257
        RETLW   $E2     ; 2274
        RETLW   $F2     ; 2290
        RETLW   $03     ; 2307
        RETLW   $14     ; 2324
        RETLW   $25     ; 2341

        RETLW   $35     ; 2357
        RETLW   $46     ; 2374
        RETLW   $57     ; 2391
        RETLW   $67     ; 2407
        RETLW   $78     ; 2424
        RETLW   $89     ; 2441
        RETLW   $9A     ; 2458
        RETLW   $AA     ; 2474

        RETLW   $BB     ; 2491
        RETLW   $CC     ; 2508
        RETLW   $DD     ; 2525
        RETLW   $ED     ; 2541
        RETLW   $FE     ; 2558
        RETLW   $0F     ; 2575
        RETLW   $20     ; 2592
        RETLW   $2D     ; 2605

        RETLW   $35     ; 2613
        RETLW   $3C     ; 2620
        RETLW   $44     ; 2628
        RETLW   $4C     ; 2636
        RETLW   $53     ; 2643
        RETLW   $5B     ; 2651
        RETLW   $62     ; 2658
        RETLW   $6A     ; 2666

        RETLW   $72     ; 2674
        RETLW   $79     ; 2681
        RETLW   $81     ; 2689
        RETLW   $89     ; 2697
        RETLW   $90     ; 2704
        RETLW   $98     ; 2712
        RETLW   $9F     ; 2719
        RETLW   $A7     ; 2727

        RETLW   $AF     ; 2735
        RETLW   $B6     ; 2742
        RETLW   $BE     ; 2750
        RETLW   $C6     ; 2758
        RETLW   $CD     ; 2765
        RETLW   $D5     ; 2773
        RETLW   $DD     ; 2781
        RETLW   $E4     ; 2788

        RETLW   $EC     ; 2796
        RETLW   $F3     ; 2803
        RETLW   $FB     ; 2811
        RETLW   $03     ; 2819
        RETLW   $0A     ; 2826
        RETLW   $12     ; 2834
        RETLW   $1A     ; 2842
        RETLW   $21     ; 2849

        RETLW   $29     ; 2857
        RETLW   $31     ; 2865
        RETLW   $39     ; 2873
        RETLW   $41     ; 2881
        RETLW   $49     ; 2889
        RETLW   $50     ; 2896
        RETLW   $58     ; 2904
        RETLW   $60     ; 2912

        RETLW   $68     ; 2920
        RETLW   $70     ; 2928
        RETLW   $77     ; 2935
        RETLW   $7F     ; 2943
        RETLW   $87     ; 2951
        RETLW   $8F     ; 2959
        RETLW   $97     ; 2967
        RETLW   $9F     ; 2975

        RETLW   $A6     ; 2982
        RETLW   $AE     ; 2990
        RETLW   $B6     ; 2998
        RETLW   $BE     ; 3006
        RETLW   $C6     ; 3014
        RETLW   $CE     ; 3022
        RETLW   $D5     ; 3029
        RETLW   $DD     ; 3037

        RETLW   $E5     ; 3045
        RETLW   $ED     ; 3053
        RETLW   $F5     ; 3061
        RETLW   $FC     ; 3068
        RETLW   $04     ; 3076
        RETLW   $0B     ; 3083
        RETLW   $12     ; 3090
        RETLW   $19     ; 3097

        RETLW   $20     ; 3104
        RETLW   $27     ; 3111
        RETLW   $2F     ; 3119
        RETLW   $36     ; 3126
        RETLW   $3D     ; 3133
        RETLW   $44     ; 3140
        RETLW   $4B     ; 3147
        RETLW   $52     ; 3154

        RETLW   $59     ; 3161
        RETLW   $60     ; 3168
        RETLW   $68     ; 3176
        RETLW   $6F     ; 3183
        RETLW   $76     ; 3190
        RETLW   $7D     ; 3197
        RETLW   $84     ; 3204
        RETLW   $8B     ; 3211

        RETLW   $92     ; 3218
        RETLW   $99     ; 3225
        RETLW   $A0     ; 3232
        RETLW   $A8     ; 3240
        RETLW   $AF     ; 3247
        RETLW   $B6     ; 3254
        RETLW   $BD     ; 3261
        RETLW   $C4     ; 3268

        RETLW   $CB     ; 3275
        RETLW   $D2     ; 3282
        RETLW   $D9     ; 3289
        RETLW   $E1     ; 3297
        RETLW   $E8     ; 3304
        RETLW   $ED     ; 3309
        RETLW   $F1     ; 3313
        RETLW   $F5     ; 3317

        RETLW   $F9     ; 3321
        RETLW   $FD     ; 3325
        RETLW   $01     ; 3329
        RETLW   $05     ; 3333
        RETLW   $0A     ; 3338
        RETLW   $0E     ; 3342
        RETLW   $12     ; 3346
        RETLW   $16     ; 3350

        RETLW   $1A     ; 3354
        RETLW   $1E     ; 3358
        RETLW   $22     ; 3362
        RETLW   $26     ; 3366
        RETLW   $2A     ; 3370
        RETLW   $2E     ; 3374
        RETLW   $32     ; 3378
        RETLW   $36     ; 3382

        RETLW   $3A     ; 3386
        RETLW   $3F     ; 3391
        RETLW   $43     ; 3395
        RETLW   $47     ; 3399
        RETLW   $4B     ; 3403
        RETLW   $4F     ; 3407
        RETLW   $53     ; 3411
        RETLW   $57     ; 3415

        RETLW   $5B     ; 3419
        RETLW   $5F     ; 3423
        RETLW   $63     ; 3427
        RETLW   $66     ; 3430
        RETLW   $69     ; 3433
        RETLW   $6C     ; 3436
        RETLW   $70     ; 3440
        RETLW   $73     ; 3443

        RETLW   $76     ; 3446
        RETLW   $7A     ; 3450
        RETLW   $7D     ; 3453
        RETLW   $80     ; 3456
        RETLW   $84     ; 3460
        RETLW   $87     ; 3463
        RETLW   $8A     ; 3466
        RETLW   $8D     ; 3469

        RETLW   $91     ; 3473
        RETLW   $94     ; 3476
        RETLW   $97     ; 3479
        RETLW   $9B     ; 3483
        RETLW   $9E     ; 3486
        RETLW   $A1     ; 3489
        RETLW   $A4     ; 3492
        RETLW   $A8     ; 3496

        RETLW   $AB     ; 3499
        RETLW   $AE     ; 3502
        RETLW   $B2     ; 3506
        RETLW   $B5     ; 3509
        RETLW   $B8     ; 3512
        RETLW   $BB     ; 3515
        RETLW   $BF     ; 3519
        RETLW   $C2     ; 3522

        RETLW   $C5     ; 3525
        RETLW   $C9     ; 3529
        RETLW   $CC     ; 3532
        RETLW   $CF     ; 3535
        RETLW   $D2     ; 3538
        RETLW   $D6     ; 3542
        RETLW   $DA     ; 3546
        RETLW   $DE     ; 3550

        RETLW   $E2     ; 3554
        RETLW   $E6     ; 3558
        RETLW   $EA     ; 3562
        RETLW   $EE     ; 3566
        RETLW   $F2     ; 3570
        RETLW   $F6     ; 3574
        RETLW   $FA     ; 3578
        RETLW   $FE     ; 3582

        RETLW   $02     ; 3586
        RETLW   $06     ; 3590
        RETLW   $0A     ; 3594
        RETLW   $0E     ; 3598
        RETLW   $12     ; 3602
        RETLW   $16     ; 3606
        RETLW   $1A     ; 3610
        RETLW   $1E     ; 3614

        RETLW   $22     ; 3618
        RETLW   $26     ; 3622
        RETLW   $2A     ; 3626
        RETLW   $2E     ; 3630
        RETLW   $32     ; 3634
        RETLW   $36     ; 3638
        RETLW   $3A     ; 3642
        RETLW   $3E     ; 3646

        RETLW   $42     ; 3650
        RETLW   $46     ; 3654
        RETLW   $4A     ; 3658
        RETLW   $4E     ; 3662
        RETLW   $52     ; 3666
        RETLW   $56     ; 3670
        RETLW   $5A     ; 3674
        RETLW   $5E     ; 3678

        RETLW   $62     ; 3682
        RETLW   $66     ; 3686
        RETLW   $6A     ; 3690
        RETLW   $6E     ; 3694
        RETLW   $72     ; 3698
        RETLW   $76     ; 3702
        RETLW   $7A     ; 3706
        RETLW   $7E     ; 3710

        RETLW   $82     ; 3714
        RETLW   $86     ; 3718
        RETLW   $8A     ; 3722
        RETLW   $8E     ; 3726
        RETLW   $92     ; 3730
        RETLW   $96     ; 3734
        RETLW   $9A     ; 3738
        RETLW   $9E     ; 3742

        RETLW   $A2     ; 3746
        RETLW   $A6     ; 3750
        RETLW   $AA     ; 3754
        RETLW   $AE     ; 3758
        RETLW   $B2     ; 3762
        RETLW   $B6     ; 3766
        RETLW   $BA     ; 3770
        RETLW   $BE     ; 3774

; ----------   INITIALIZATION CODE   ----------

INIT    XORLW   $FF             ; UNPROGRAMED NOP

        MOVLW   $0F             ; INITIALIZE PORTA & PORTB
        MOVWF   PORTA
        MOVLW   $FF
        MOVWF   PORTB

        BANK1
        MOVLW   $0F             ; SET DATA DIRECTION OF PORTA & PORTB
        MOVWF   TRISA
        MOVLW   $00
        MOVWF   TRISB
        MOVLW   $81
        MOVWF   OPTION_REG
        MOVLW   $02
        MOVWF   ADCON1
        BANK0

        MOVLW   $C1
        MOVWF   ADCON0

        CLRF    AD_ISR
        BCF     PORTB,OKAY

        CLRF    INTCON
        BSF     INTCON,T0IE
        BSF     INTCON,GIE

; ----------   MAIN CODE   ----------

MAIN
        MOVLW   HIGH OUT
        MOVWF   PCLATH
        COMF    AD_ISR,W
        MOVWF   TXSR
        BCF     PORTB,LEDS

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        COMF    SHOW,W
        MOVWF   TXSR

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        BSF     PORTB,LEDS
        GOTO    MAIN


; ----------   OUTPUT SERIAL BITS   ----------

OUT
        BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        BSF     PORTB,SCLK
        RETURN

; ----------   MSBTAB   ----------

        ORG     $2FE
MSBTAB  INCF    PCLATH,F
        ADDWF   PCL,F
           
        RETLW   $50     ; 1460
        RETLW   $50     ; 1524
        RETLW   $60     ; 1587
        RETLW   $60     ; 1651
        RETLW   $60     ; 1714
        RETLW   $60     ; 1778
        RETLW   $70     ; 1842
        RETLW   $70     ; 1905

        RETLW   $70     ; 1969
        RETLW   $70     ; 2032
        RETLW   $80     ; 2096
        RETLW   $80     ; 2140
        RETLW   $80     ; 2156
        RETLW   $80     ; 2173
        RETLW   $80     ; 2190
        RETLW   $80     ; 2207

        RETLW   $80     ; 2223
        RETLW   $80     ; 2240
        RETLW   $80     ; 2257
        RETLW   $80     ; 2274
        RETLW   $80     ; 2290
        RETLW   $90     ; 2307
        RETLW   $90     ; 2324
        RETLW   $90     ; 2341

        RETLW   $90     ; 2357
        RETLW   $90     ; 2374
        RETLW   $90     ; 2391
        RETLW   $90     ; 2407
        RETLW   $90     ; 2424
        RETLW   $90     ; 2441
        RETLW   $90     ; 2458
        RETLW   $90     ; 2474

        RETLW   $90     ; 2491
        RETLW   $90     ; 2508
        RETLW   $90     ; 2525
        RETLW   $90     ; 2541
        RETLW   $90     ; 2558
        RETLW   $A0     ; 2575
        RETLW   $A0     ; 2592
        RETLW   $A0     ; 2605

        RETLW   $A0     ; 2613
        RETLW   $A0     ; 2620
        RETLW   $A0     ; 2628
        RETLW   $A0     ; 2636
        RETLW   $A0     ; 2643
        RETLW   $A0     ; 2651
        RETLW   $A0     ; 2658
        RETLW   $A0     ; 2666

        RETLW   $A0     ; 2674
        RETLW   $A0     ; 2681
        RETLW   $A0     ; 2689
        RETLW   $A0     ; 2697
        RETLW   $A0     ; 2704
        RETLW   $A0     ; 2712
        RETLW   $A0     ; 2719
        RETLW   $A0     ; 2727

        RETLW   $A0     ; 2735
        RETLW   $A0     ; 2742
        RETLW   $A0     ; 2750
        RETLW   $A0     ; 2758
        RETLW   $A0     ; 2765
        RETLW   $A0     ; 2773
        RETLW   $A0     ; 2781
        RETLW   $A0     ; 2788

        RETLW   $A0     ; 2796
        RETLW   $A0     ; 2803
        RETLW   $A0     ; 2811
        RETLW   $B0     ; 2819
        RETLW   $B0     ; 2826
        RETLW   $B0     ; 2834
        RETLW   $B0     ; 2842
        RETLW   $B0     ; 2849

        RETLW   $B0     ; 2857
        RETLW   $B0     ; 2865
        RETLW   $B0     ; 2873
        RETLW   $B0     ; 2881
        RETLW   $B0     ; 2889
        RETLW   $B0     ; 2896
        RETLW   $B0     ; 2904
        RETLW   $B0     ; 2912

        RETLW   $B0     ; 2920
        RETLW   $B0     ; 2928
        RETLW   $B0     ; 2935
        RETLW   $B0     ; 2943
        RETLW   $B0     ; 2951
        RETLW   $B0     ; 2959
        RETLW   $B0     ; 2967
        RETLW   $B0     ; 2975

        RETLW   $B0     ; 2982
        RETLW   $B0     ; 2990
        RETLW   $B0     ; 2998
        RETLW   $B0     ; 3006
        RETLW   $B0     ; 3014
        RETLW   $B0     ; 3022
        RETLW   $B0     ; 3029
        RETLW   $B0     ; 3037

        RETLW   $B0     ; 3045
        RETLW   $B0     ; 3053
        RETLW   $B0     ; 3061
        RETLW   $B0     ; 3068
        RETLW   $C0     ; 3076
        RETLW   $C0     ; 3083
        RETLW   $C0     ; 3090
        RETLW   $C0     ; 3097

        RETLW   $C0     ; 3104
        RETLW   $C0     ; 3111
        RETLW   $C0     ; 3119
        RETLW   $C0     ; 3126
        RETLW   $C0     ; 3133
        RETLW   $C0     ; 3140
        RETLW   $C0     ; 3147
        RETLW   $C0     ; 3154

        RETLW   $C0     ; 3161
        RETLW   $C0     ; 3168
        RETLW   $C0     ; 3176
        RETLW   $C0     ; 3183
        RETLW   $C0     ; 3190
        RETLW   $C0     ; 3197
        RETLW   $C0     ; 3204
        RETLW   $C0     ; 3211

        RETLW   $C0     ; 3218
        RETLW   $C0     ; 3225
        RETLW   $C0     ; 3232
        RETLW   $C0     ; 3240
        RETLW   $C0     ; 3247
        RETLW   $C0     ; 3254
        RETLW   $C0     ; 3261
        RETLW   $C0     ; 3268

        RETLW   $C0     ; 3275
        RETLW   $C0     ; 3282
        RETLW   $C0     ; 3289
        RETLW   $C0     ; 3297
        RETLW   $C0     ; 3304
        RETLW   $C0     ; 3309
        RETLW   $C0     ; 3313
        RETLW   $C0     ; 3317

        RETLW   $C0     ; 3321
        RETLW   $C0     ; 3325
        RETLW   $D0     ; 3329
        RETLW   $D0     ; 3333
        RETLW   $D0     ; 3338
        RETLW   $D0     ; 3342
        RETLW   $D0     ; 3346
        RETLW   $D0     ; 3350

        RETLW   $D0     ; 3354
        RETLW   $D0     ; 3358
        RETLW   $D0     ; 3362
        RETLW   $D0     ; 3366
        RETLW   $D0     ; 3370
        RETLW   $D0     ; 3374
        RETLW   $D0     ; 3378
        RETLW   $D0     ; 3382

        RETLW   $D0     ; 3386
        RETLW   $D0     ; 3391
        RETLW   $D0     ; 3395
        RETLW   $D0     ; 3399
        RETLW   $D0     ; 3403
        RETLW   $D0     ; 3407
        RETLW   $D0     ; 3411
        RETLW   $D0     ; 3415

        RETLW   $D0     ; 3419
        RETLW   $D0     ; 3423
        RETLW   $D0     ; 3427
        RETLW   $D0     ; 3430
        RETLW   $D0     ; 3433
        RETLW   $D0     ; 3436
        RETLW   $D0     ; 3440
        RETLW   $D0     ; 3443

        RETLW   $D0     ; 3446
        RETLW   $D0     ; 3450
        RETLW   $D0     ; 3453
        RETLW   $D0     ; 3456
        RETLW   $D0     ; 3460
        RETLW   $D0     ; 3463
        RETLW   $D0     ; 3466
        RETLW   $D0     ; 3469

        RETLW   $D0     ; 3473
        RETLW   $D0     ; 3476
        RETLW   $D0     ; 3479
        RETLW   $D0     ; 3483
        RETLW   $D0     ; 3486
        RETLW   $D0     ; 3489
        RETLW   $D0     ; 3492
        RETLW   $D0     ; 3496

        RETLW   $D0     ; 3499
        RETLW   $D0     ; 3502
        RETLW   $D0     ; 3506
        RETLW   $D0     ; 3509
        RETLW   $D0     ; 3512
        RETLW   $D0     ; 3515
        RETLW   $D0     ; 3519
        RETLW   $D0     ; 3522

        RETLW   $D0     ; 3525
        RETLW   $D0     ; 3529
        RETLW   $D0     ; 3532
        RETLW   $D0     ; 3535
        RETLW   $D0     ; 3538
        RETLW   $D0     ; 3542
        RETLW   $D0     ; 3546
        RETLW   $D0     ; 3550

        RETLW   $D0     ; 3554
        RETLW   $D0     ; 3558
        RETLW   $D0     ; 3562
        RETLW   $D0     ; 3566
        RETLW   $D0     ; 3570
        RETLW   $D0     ; 3574
        RETLW   $D0     ; 3578
        RETLW   $D0     ; 3582

        RETLW   $E0     ; 3586
        RETLW   $E0     ; 3590
        RETLW   $E0     ; 3594
        RETLW   $E0     ; 3598
        RETLW   $E0     ; 3602
        RETLW   $E0     ; 3606
        RETLW   $E0     ; 3610
        RETLW   $E0     ; 3614

        RETLW   $E0     ; 3618
        RETLW   $E0     ; 3622
        RETLW   $E0     ; 3626
        RETLW   $E0     ; 3630
        RETLW   $E0     ; 3634
        RETLW   $E0     ; 3638
        RETLW   $E0     ; 3642
        RETLW   $E0     ; 3646

        RETLW   $E0     ; 3650
        RETLW   $E0     ; 3654
        RETLW   $E0     ; 3658
        RETLW   $E0     ; 3662
        RETLW   $E0     ; 3666
        RETLW   $E0     ; 3670
        RETLW   $E0     ; 3674
        RETLW   $E0     ; 3678

        RETLW   $E0     ; 3682
        RETLW   $E0     ; 3686
        RETLW   $E0     ; 3690
        RETLW   $E0     ; 3694
        RETLW   $E0     ; 3698
        RETLW   $E0     ; 3702
        RETLW   $E0     ; 3706
        RETLW   $E0     ; 3710

        RETLW   $E0     ; 3714
        RETLW   $E0     ; 3718
        RETLW   $E0     ; 3722
        RETLW   $E0     ; 3726
        RETLW   $E0     ; 3730
        RETLW   $E0     ; 3734
        RETLW   $E0     ; 3738
        RETLW   $E0     ; 3742

        RETLW   $E0     ; 3746
        RETLW   $E0     ; 3750
        RETLW   $E0     ; 3754
        RETLW   $E0     ; 3758
        RETLW   $E0     ; 3762
        RETLW   $E0     ; 3766
        RETLW   $E0     ; 3770
        RETLW   $E0     ; 3774

        END
