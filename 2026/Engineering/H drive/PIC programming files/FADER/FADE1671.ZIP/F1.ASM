        LIST    F=INHX8M,R=DEC,P=16C54
; ----------   PIC16C5X HEADER   ----------

W       EQU     0

; RESET ADDRESSES

PIC54   EQU     $1FF
PIC55   EQU     $1FF
PIC56   EQU     $3FF
PIC57   EQU     $7FF

; STATUS WORD REGISTER f3

C       EQU     0
DC      EQU     1
Z       EQU     2
PD      EQU     3
TO      EQU     4
PA0     EQU     5
PA1     EQU     6
PA2     EQU     7

; OPERATIONAL REGISTER FILES

IND     EQU     00
RTCC    EQU     01
PC      EQU     02
STATUS  EQU     03
FSR     EQU     04
PORTA   EQU     05
PORTB   EQU     06
PORTC   EQU     07

; ----------   END HEADER   ----------

        ORG     8

STATE   RES     1
HI      RES     1
LEVEL   RES     1

; ----------   EQUATES   ----------

                                ; USE 4K7 AND 330pF FOR RC OSC
                                ; OS2 = 125kHz
DELAY   EQU     101             ;   5 msec with OPTION $01

; ----------   PORTB BITS   ----------

OKAY    EQU     0
TALLY   EQU     1
S1IN    EQU     2
S2IN    EQU     3
DAC     EQU     4
LEDS    EQU     5
SCLK    EQU     6
SDATA   EQU     7

        ORG     $100

; ----------   NEXT STATE TABLE1   ----------

; DEBOUNCE INPUT STATE MACHINE
; BIT 0 INPUT - ACTIVE HIGH
; BIT 1 STATE
; BIT 2 STATE
; BIT 3 OUTPUT - SET AFTER INPUT=1 FOUR CONSECUTIVE TIMES
; BIT 4 OUTPUT - SET AFTER BIT 3 TOGGLES

KEYBIT  EQU     3
KCH     EQU     4

NEXT1   ANDLW   $0F     ; DEBOUNCE INPUT STATE MACHINE
        ADDWF   PC

        RETLW   0       ; KEYBIT CLEAR WHILE INPUT=0
        RETLW   2
        RETLW   0
        RETLW   4
        RETLW   0
        RETLW   6
        RETLW   0
        RETLW   8+16    ; 4TH INPUT=1 SO SET KEYBIT

        RETLW   10
        RETLW   8       ; KEYBIT SET WHILE INPUT=1
        RETLW   12
        RETLW   8
        RETLW   14
        RETLW   8
        RETLW   0+16    ; 4TH INPUT=0 SO CLEAR KEYBIT
        RETLW   8

; ----------   NEXT STATE TABLE2   ----------

TINC    EQU     7
TDEC    EQU     6
TCH     EQU     5
TCH     EQU     4

TABLE2  ANDLW   $1F     ; DEBOUNCE INPUT STATE MACHINE
        ADDWF   PC
; DOWN
        RETLW   $00+$00
        RETLW   $04+$40
        RETLW   $18+$A0
        RETLW   $0C+$00
        RETLW   $10+$A0
        RETLW   $04+$00
        RETLW   $08+$00
        RETLW   $0C+$40
        RETLW   $00+$40
        RETLW   $04+$00
        RETLW   $08+$00
        RETLW   $1C+$A0
        RETLW   $00+$00
        RETLW   $14+$A0
        RETLW   $08+$40
        RETLW   $0C+$00
; UP
        RETLW   $10+$00
        RETLW   $04+$60
        RETLW   $18+$80
        RETLW   $1C+$00
        RETLW   $10+$80
        RETLW   $14+$00
        RETLW   $18+$00
        RETLW   $0C+$60
        RETLW   $00+$60
        RETLW   $14+$00
        RETLW   $18+$00
        RETLW   $1C+$80
        RETLW   $10+$00
        RETLW   $14+$80
        RETLW   $08+$60
        RETLW   $1C+$00


; ----------   INITIALIZATION CODE   ----------

        ORG     $100
INIT    XORLW   $FF             ; UNPROGRAMED NOP

        MOVLW   $0F
        MOVWF   PORTA           ; INITIALIZE PORTA
        TRIS    PORTA

        MOVLW   $FF             ; INITIALIZE PORTB
        MOVWF   PORTB
        CLRW
        TRIS    PORTB

        CLRF    S1
        CLRF    S2

        MOVLW   $06             ; RTCC = OSC2 / 128
        OPTION

        MOVLW   DELAY1          ; RESET COUNTER
        MOVWF   RTCC



; ----------   MAIN CODE   ----------


WAIT    MOVF    RTCC,W
        BTFSS   STATUS,Z
        GOTO    WAIT            ; WAIT FOR TIME OUT

        MOVLW   DELAY2
        MOVWF   RTCC            ; RESET COUNTER


        MOVLW   $03
        ANDWF   S1
        ANDWF   S2

        BTFSS   PORTB,S1IN
        INCF    S1
        BTFSS   PORTB,S2IN
        INCF    S2

        MOVF    S1,W
        CALL    NEXT1
        MOVWF   S1

        MOVF    S2,W
        CALL    NEXT1
        MOVWF   S2

        BTFSS


        BTFSC   IND,KEYBIT
        GOTO    GOTONE          ; FOUND HIGHEST PRIORITY KEY

        INCF    FSR
        DECFSZ  I
        GOTO    PRIO
        GOTO    NONE            ; NO KEYS PRESSED

        ORG     PIC54
RESET   GOTO    INIT
        END
