        LIST    F=INHX8M,R=DEC,P=16C71
        INCLUDE "\PIC\SRC\P16C71.INC"
        INCLUDE "\PIC\SRC\MACROS.ASM"

; ----------   MACROS   ----------

BANK0   MACRO
        BCF     STATUS,RP0
        ENDM

BANK1   MACRO
        BSF     STATUS,RP0
        ENDM

; ----------   .   ----------

; ----------   RAM   ----------

        ORG     $0C

W_ISR   RES     1
ST_ISR  RES     1
AD_ISR  RES     1
TX_ISR  RES     1
I_ISR   RES     1

STATE   RES     1
HI      RES     1
LEVEL   RES     1
I       RES     1
TXSR    RES     1

; ----------   PORTB BITS   ----------

S1IN    EQU     0
S2IN    EQU     1
OKAY    EQU     2
TALLY   EQU     3
DAC     EQU     4
LEDS    EQU     5
SCLK    EQU     6
SDATA   EQU     7

; ----------   CODE   ----------

        ORG     0

RESET   XORLW   $FF
        XORLW   $FF
        XORLW   $FF
        GOTO    INIT

; ----------   INTERRUPT SUBROUTINE   ----------

        ORG     4

ISR     MOVWF   W_ISR
        SWAPF   STATUS,W
        MOVWF   ST_ISR

        IFCLR   INTCON,T0IF
        GOTO    EXITISR

        BANK0
        MOVLW   156
        MOVWF   TMR0
        BCF     INTCON,T0IF
        BCF     PORTB,TALLY

        BSF     ADCON,GO        ; START A/D CONVERSION
ISR_L1  NOP
        IFCLR   ADCON,GO
        GOTO    ISR_L1

        BSF     PORTB,TALLY

        MOVF    ADRES,W
        SUBWF   AD_ISR,W
        IFZ
        GOTO    EXITISR

        BCF     PORTB,DAC       ; UPDATE DAC OUTPUT

        MOVLW   HIGH MSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        MOVWF   AD_ISR
        CALL    MSBTAB
        MOVWF   TX_ISR

        MOVLW   4
        MOVWF   I_ISR
ISR_L2  BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TX_ISR,F
        BSF     PORTB,SCLK
        DECFSZ  I_ISR
        GOTO    ISR_L2

        MOVLW   HIGH LSBTAB
        MOVWF   PCLATH
        MOVF    ADRES,W
        CALL    LSBTAB
        MOVWF   TX_ISR

        MOVLW   8
        MOVWF   I_ISR
ISR_L3  BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TX_ISR,F
        BSF     PORTB,SCLK
        DECFSZ  I_ISR
        GOTO    ISR_L3

        BSF     PORTB,DAC

EXITISR SWAPF   ST_ISR,W
        MOVWF   STATUS
        SWAPF   W_ISR,F
        SWAPF   W_ISR,W
        RETFIE

; ----------   OUTPUT SERIAL BITS   ----------

OUT
        BCF     PORTB,SCLK
        IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        BSF     PORTB,SCLK
        RETURN



; ----------   LSBTAB   ----------

        ORG     $FE
LSBTAB  INCF    PCLATH
        ADDWF   PCL,F


; ----------   INITIALIZATION CODE   ----------

INIT    XORLW   $FF             ; UNPROGRAMED NOP

        MOVLW   $0F             ; INITIALIZE PORTA & PORTB
        MOVWF   PORTA
        MOVLW   $FF
        MOVWF   PORTB

        BANK1
        MOVLW   $0F             ; SET DATA DIRECTION OF PORTA & PORTB
        MOVWF   TRISA
        MOVLW   $03
        MOVWF   TRISB
        MOVLW   $81
        MOVWF   OPTION
        MOVLW   $02
        MOVWF   ADCON1
        BANK0

        MOVLW   $C1
        MOVWF   ADCON0

        BCF     PORTB,OKAY


; ----------   MAIN CODE   ----------


SEND    MOVF    PORTA,W
        MOVWF   HI

        SWAPF   HI,W
        MOVWF   TXSR
        BCF     PORTB,DAC

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        MOVF    LEVEL,W
        MOVWF   TXSR

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        BSF     PORTB,DAC

        COMF    LEVEL,W
        MOVWF   TXSR
        BCF     PORTB,LEDS

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        COMF    HI,W
        MOVWF   TXSR

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        BSF     PORTB,LEDS
        GOTO    MAIN

; ----------   MSBTAB   ----------

        ORG     $2FE
MSBTAB  INCF    PCLATH
        ADDWF   PCL,F



        END
