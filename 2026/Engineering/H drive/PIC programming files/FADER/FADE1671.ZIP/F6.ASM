        LIST    F=INHX8M,R=DEC,P=16C54
        INCLUDE "\PIC\SRC\P16C5X.INC"
        INCLUDE "\PIC\SRC\MACROS.ASM"

        ORG     8

STATE   RES     1
HI      RES     1
LEVEL   RES     1
I       RES     1
TXSR    RES     1

; ----------   PORTB BITS   ----------

S1IN    EQU     0
S2IN    EQU     1
OKAY    EQU     2
TALLY   EQU     3
DAC     EQU     4
LEDS    EQU     5
SCLK    EQU     6
SDATA   EQU     7

        ORG     0

; ----------   NEXT STATE TABLE1   ----------

TINC    EQU     7
TDEC    EQU     6
TCH     EQU     5

TABLE1  ANDLW   $1F     ; DEBOUNCE INPUT STATE MACHINE
        ADDWF   PCL,F
; DOWN
        RETLW   $00+$00
        RETLW   $04+$40
        RETLW   $18+$A0
        RETLW   $0C+$00
        RETLW   $10+$A0
        RETLW   $04+$00
        RETLW   $08+$00
        RETLW   $0C+$40
        RETLW   $00+$40
        RETLW   $04+$00
        RETLW   $08+$00
        RETLW   $1C+$A0
        RETLW   $00+$00
        RETLW   $14+$A0
        RETLW   $08+$40
        RETLW   $0C+$00
; UP
        RETLW   $10+$00
        RETLW   $04+$60
        RETLW   $18+$80
        RETLW   $1C+$00
        RETLW   $10+$80
        RETLW   $14+$00
        RETLW   $18+$00
        RETLW   $0C+$60
        RETLW   $00+$60
        RETLW   $14+$00
        RETLW   $18+$00
        RETLW   $1C+$80
        RETLW   $10+$00
        RETLW   $14+$80
        RETLW   $08+$60
        RETLW   $1C+$00

; ----------   OUTPUT SERIAL BITS   ----------

OUT     IFSET   TXSR,7
        BSF     PORTB,SDATA
        IFCLR   TXSR,7
        BCF     PORTB,SDATA
        RLF     TXSR,F
        NOP
        NOP
        BSF     PORTB,SCLK
        NOP
        NOP
        NOP
        BCF     PORTB,SCLK
        RETLW   0


; ----------   INITIALIZATION CODE   ----------

        ORG     $100
INIT    XORLW   $FF             ; UNPROGRAMED NOP

        MOVLW   $0F
        MOVWF   PORTA           ; INITIALIZE PORTA
        TRIS    PORTA

        MOVLW   $FF             ; INITIALIZE PORTB
        MOVWF   PORTB
        MOVLW   $03
        TRIS    PORTB

        BCF     PORTB,OKAY

        CLRF    STATE
        CLRF    LEVEL
        MOVF    PORTA,W
        MOVWF   HI

; ----------   MAIN CODE   ----------

MAIN
        MOVLW   $1C
        ANDWF   STATE,F

        MOVF    PORTB,W
        ANDLW   $03
        IORWF   STATE,W
        CALL    TABLE1
        MOVWF   STATE

        IFSET   STATE,TINC
        GOTO    DOINC
        IFSET   STATE,TDEC
        GOTO    DODEC

        MOVF    HI,W
        SUBWF   PORTA,W
        IFZ
        GOTO    MAIN
        GOTO    SEND

DOINC   INCF    LEVEL,F
        GOTO    SEND

DODEC   DECF    LEVEL,F
        GOTO    SEND

SEND    MOVF    PORTA,W
        MOVWF   HI

        SWAPF   HI,W
        MOVWF   TXSR
        BCF     PORTB,DAC

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        MOVF    LEVEL,W
        MOVWF   TXSR

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        BSF     PORTB,DAC

        COMF    LEVEL,W
        MOVWF   TXSR
        BCF     PORTB,LEDS

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        COMF    HI,W
        MOVWF   TXSR

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        CALL    OUT
        CALL    OUT
        CALL    OUT
        CALL    OUT

        BSF     PORTB,LEDS
        GOTO    MAIN

        ORG     $1FF
RESET   GOTO    INIT
        END
