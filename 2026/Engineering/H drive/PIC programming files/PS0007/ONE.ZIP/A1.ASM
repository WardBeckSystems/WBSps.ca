        LIST    F=INHX8M,R=DEC,P=16C54
; ----------   PIC16C5X HEADER   ----------

W       EQU     0

; RESET ADDRESSES

PIC54   EQU     $1FF
PIC55   EQU     $1FF
PIC56   EQU     $3FF
PIC57   EQU     $7FF

; STATUS WORD REGISTER f3

C       EQU     0
DC      EQU     1
Z       EQU     2
PD      EQU     3
TO      EQU     4
PA0     EQU     5
PA1     EQU     6
PA2     EQU     7

; OPERATIONAL REGISTER FILES

IND     EQU     00
RTCC    EQU     01
PC      EQU     02
STATUS  EQU     03
FSR     EQU     04
PORTA   EQU     05
PORTB   EQU     06
PORTC   EQU     07

; ----------   END HEADER   ----------

I       EQU     08
KEY     EQU     09

KEYST   EQU     10              ; KEYSWITCH DEBOUNCE STATES

KEY1    EQU     10
KEY2    EQU     11
KEY3    EQU     12
KEY4    EQU     13
KEY5    EQU     14
KEY6    EQU     15

; ----------   EQUATES   ----------

NKEYS   EQU     6               ; NUMBER OF KEYS

                                ; USE 4K7 AND 330pF FOR RC OSC
                                ; OS2 = 125kHz
DELAY1  EQU     12              ; 250 msec with OPTION $06
DELAY2  EQU     101             ;   5 msec with OPTION $01

; ----------   NEXT STATE TABLE1   ----------

        ORG     $000
                        ; SET BIT 0 OF THE STATE TO INPUT
                        ; BEFORE CALLING NEXT1
KEYBIT  EQU     3       ; BIT TEST KEYBIT AFTER CALLING NEXT1

NEXT1   ANDLW   $0F     ; DEBOUNCE INPUT STATE MACHINE
        ADDWF   PC

        RETLW   0       ; KEYBIT CLEAR WHILE INPUT=0
        RETLW   2
        RETLW   0
        RETLW   4
        RETLW   0
        RETLW   6
        RETLW   0
        RETLW   8       ; 4TH INPUT=1 SO SET KEYBIT

        RETLW   10
        RETLW   8       ; KEYBIT SET WHILE INPUT=1
        RETLW   12
        RETLW   8
        RETLW   14
        RETLW   8
        RETLW   0       ; 4TH INPUT=0 SO CLEAR KEYBIT
        RETLW   8

; ----------   INITIALIZATION CODE   ----------

        ORG     $1B0
INIT    XORLW   $FF             ; UNPROGRAMED NOP

        MOVLW   $0F
        MOVWF   PORTA           ; INITIALIZE PORTA
        MOVLW   $08
        TRIS    PORTA

        MOVLW   $FF             ; INITIALIZE PORTB
        TRIS    PORTB

        MOVLW   KEYST           ; BLANK INPUT AND KEYSWITCH STATES
        MOVWF   FSR
        MOVLW   NKEYS
        MOVWF   I
BLANK   CLRF    IND
        INCF    FSR
        DECFSZ  I
        GOTO    BLANK

        MOVLW   $06             ; RTCC = OSC2 / 128
        OPTION

        MOVLW   NKEYS
        MOVWF   I

SEQ1    MOVLW   DELAY1          ; RESET COUNTER
        MOVWF   RTCC

        DECF    I,W
        MOVWF   PORTA

SEQ2    MOVF    RTCC,W
        BTFSS   STATUS,Z
        GOTO    SEQ2            ; WAIT FOR TIME OUT

        DECFSZ  I
        GOTO    SEQ1

        MOVLW   $01             ; RTCC = OSC2 / 4
        OPTION

        MOVLW   KEYST
        MOVWF   FSR

; ----------   MAIN CODE   ----------

GOTONE  MOVLW   KEYST
        SUBWF   FSR,W
        MOVWF   KEY
NONE
HELD
        MOVF    KEY,W
        MOVWF   PORTA

WAIT    MOVF    RTCC,W
        BTFSS   STATUS,Z
        GOTO    WAIT            ; WAIT FOR TIME OUT

        MOVLW   DELAY2
        MOVWF   RTCC            ; RESET COUNTER
SCAN
        BTFSS   PORTB,0
        INCF    KEY1
        BTFSS   PORTB,1
        INCF    KEY2
        BTFSS   PORTB,2
        INCF    KEY3
        BTFSS   PORTB,3
        INCF    KEY4
        BTFSS   PORTB,4
        INCF    KEY5
        BTFSS   PORTB,5
        INCF    KEY6

        MOVLW   KEYST
        MOVWF   FSR
        MOVLW   NKEYS
        MOVWF   I

UPDATE  MOVF    IND,W
        CALL    NEXT1
        MOVWF   IND
        INCF    FSR

        DECFSZ  I
        GOTO    UPDATE

        MOVLW   KEYST           ; CHECK FOR RELEASE
        ADDWF   KEY,W
        MOVWF   FSR
        BTFSC   IND,KEYBIT
        GOTO    HELD            ; KEY NOT RELEASED YET

        MOVLW   KEYST
        MOVWF   FSR
        MOVLW   NKEYS           ; GET HIGHEST PRIORITY KEY
        MOVWF   I

PRIO
        BTFSC   IND,KEYBIT
        GOTO    GOTONE          ; FOUND HIGHEST PRIORITY KEY

        INCF    FSR
        DECFSZ  I
        GOTO    PRIO
        GOTO    NONE            ; NO KEYS PRESSED

        ORG     PIC54
RESET   GOTO    INIT
        END
